from django.apps import AppConfig


class Myneo4JConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myneo4j'
