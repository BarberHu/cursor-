# 环境安装
- python=3.7+
- Django = 3.2.7

# 安装方法
- pip install -r requests.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/
- python manage.py runserver 
- 浏览器打开 http://127.0.0.1:8000/

开始在加载词表。会比较慢，需要几十秒，加载完成之后才能启动系统
稍等





